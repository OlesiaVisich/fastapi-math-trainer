"""Главная точка входа FastAPI: уроки + веб-страницы."""
import os

from fastapi import FastAPI
from fastapi.responses import FileResponse

from app.api import lessons

app = FastAPI()
app.include_router(lessons.router, prefix="/lessons", tags=["lessons"])

STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")


@app.get("/", include_in_schema=False)
def index():
    """Главная страница: форма создания урока."""
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


@app.get("/lessons-page", include_in_schema=False)
def lessons_page():
    """Страница «Мои уроки» с разделами по классам."""
    return FileResponse(os.path.join(STATIC_DIR, "lessons.html"))
